package homework.figurepainter;

public class FigurePainterTest {
    public static void main(String[] args) {
        FigurePainter fp = new FigurePainter();
        fp.figureOne(2,'`');
        fp.figureOne(3,'/');
        fp.figureOne(5,'?');
        fp.figureOne(7,'*');

//        System.out.println();
//        fp.figureTwo();
//        System.out.println();
//        fp.figureThree();
//        System.out.println();
//        fp.figureFour();
//        System.out.println();
//        fp.figureFive();



    }
}
