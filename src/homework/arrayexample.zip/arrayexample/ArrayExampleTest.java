package homework.arrayexample;

public class ArrayExampleTest {
    public static void main(String[] args) {
        ArrayExample ae = new ArrayExample();
        int[] array = {1, 44, 8, 20, 11, 6, 6, 44};
        ae.printIsExists(array);
        ae.index(array);
        ae.pointIndex(array);
        ae.sameElements(array);
        ae.sortArray1(array);
        ae.sortArray2(array);
        ae.secMax(array);


    }


}
